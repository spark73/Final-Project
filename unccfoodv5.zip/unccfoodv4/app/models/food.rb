class Food < ApplicationRecord
  belongs_to :restaurant
end
