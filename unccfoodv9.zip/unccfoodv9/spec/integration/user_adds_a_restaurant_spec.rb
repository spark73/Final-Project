require 'rails_helper.rb'

feature "User adds new restaurant" do
    scenario "User sucessfully navigates to new restaurant from listing restaurants page" do
            
            visit restaurants_path
            expect(page).to have_content("List of fast food restaurants")
            click_link "Add New Restaurant"
            expect(page).to have_content("New Restaurant")
            expect(page).to have_field("restaurant_name")
            expect(page).to have_field('restaurant_image')
    end
    
    scenario "User sucessfully creates a new restaurant" do
        visit new_restaurant_path
        expect(page).to have_content("New Restaurant")
        fill_in "restaurant_name", with: "New Capybara Restaurant"
        fill_in "restaurant_image", with: "/assets/Bojangles"
        click_button "Create Restaurant"
        expect(page).to have_content("New Capybara Restaurant")
    end
    
    scenario "Should fail to create new restaurant if no user input for restaurant name" do
        visit new_restaurant_path
        expect(page).to have_content("New Restaurant")
        fill_in "restaurant_image", with: "/assets/Bojangles"
        click_button "Create Restaurant"
        expect(page).to have_content("Name can't be blank")
    end
    
    scenario "Should fail to create new restaurant if no user input for restaurant image" do
        visit new_restaurant_path
        expect(page).to have_content("New Restaurant")
        fill_in "restaurant_name", with: "Bojangles"
        click_button "Create Restaurant"
        expect(page).to have_content("Image can't be blank")
    end
end